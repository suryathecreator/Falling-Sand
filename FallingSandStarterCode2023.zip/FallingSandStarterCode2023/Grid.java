// A grid of particles
public class Grid {
  // Instance Variables
  private Particle[][] world;
  private int width, height;

  // Main constructor
  public Grid(int width, int height) {
    // set width and height
    // YOUR CODE HERE: set width and height

    // initialize world
    // YOUR CODE HERE: create the 2D-array world

    // fill with air particles
    // and add barriers along edges
    for (int x = 0; x < width; x++) {
      for (int y = 0; y < height; y++) {
        // YOUR CODE HERE: set (x, y) to a new particle
        // Hint: you will need to use the this keyword to 
        // reference this Grid instance
      }
    }
  }

  // Grid accessor and mutator
  public Particle get(int x, int y) {
    // YOUR CODE HERE: Return the particle at (x, y)
    return null; // delete this line of code
  }
  public void set(int x, int y, Particle value) {
    // YOUR CODE HERE: set the particle at (x, y) to value
  }

  // Utility method to swap particles
  public void swap(int x1, int y1, int x2, int y2) {
    // Move particles
    // YOUR CODE HERE: swap the particles by calling set

    // Pass new coords (do not edit)
    get(x1, y1).moveTo(x1,y1);
    get(x2, y2).moveTo(x2, y2);
  }
}