import java.awt.*;

// Stone particles
public class Stone extends FixedParticle {
    
  public Stone(){};
  
  public Stone(Grid grid, int x, int y){
            super(grid, x, y);      
  }  
  // YOUR CODE HERE: write a color() method
}