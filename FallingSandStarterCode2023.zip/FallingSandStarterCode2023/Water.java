import java.awt.*;

// Water particles
public class Water extends LiquidParticle {
    
  public Water(){}
  
  public Water(Grid grid, int x, int y){
            super(grid, x, y);      
  }  
  // YOUR CODE HERE: write a color() method
}