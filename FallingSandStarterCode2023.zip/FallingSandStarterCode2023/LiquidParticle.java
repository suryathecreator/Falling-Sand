import java.util.*;
import java.awt.*;

// Abstract base class for liqudid particles
public abstract class LiquidParticle extends Particle {
    
  public LiquidParticle(){}
  
  public LiquidParticle(Grid grid, int x, int y){
            super(grid, x, y);      
  }  
  // Randomly move left, right, or down
  public void step() {
    // YOUR CODE HERE: randomly swap with a particle to the
    // left, right, or down, if it is Air
  }

  // Note: you may want to write a trySwap() helper method here
  // to make your code more concise, but you don't need to.
}