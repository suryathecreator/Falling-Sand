import java.awt.*;

// Air particles
public class Air extends FixedParticle {
    
  public Air(){}
  
  public Air(Grid grid, int x, int y){
            super(grid, x, y);      
  }  
  // YOUR CODE HERE: write a color() method
}