import java.awt.*;

// Abstract base class for gravity particles
public abstract class GravityParticle extends Particle {
    
  public GravityParticle(){}
    
  public GravityParticle(Grid grid, int x, int y){
            super(grid, x, y);      
  }  
  
  public void step() {
    // YOUR CODE HERE: swap with (x, y-1) if it is Air
  }
}