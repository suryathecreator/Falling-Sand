import java.awt.*;

// Barrier particles
public class Barrier extends FixedParticle {
    
  public Barrier(){}
  
  public  Barrier(Grid grid, int x, int y){
            super(grid, x, y);      
  }
  // YOUR CODE HERE: write a color() method
}